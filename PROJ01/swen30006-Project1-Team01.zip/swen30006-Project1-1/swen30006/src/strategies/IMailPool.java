package strategies;


import automail.IRobot;
import automail.MailItem;
import exceptions.BreakingFragileItemException;
import exceptions.ItemTooHeavyException;

/**
 * addToPool is called when there are mail items newly arrived at the building to add to the MailPool or
 * if a robot returns with some undelivered items - these are added back to the MailPool.
 * The data structure and algorithms used in the MailPool is your choice.
 */
public interface IMailPool {

    /**
     * Adds an item to the mail pool
     *
     * @param mailItem the mail item being added.
     */
    void addToPool(MailItem mailItem);

    /**
     * Current robot register that it is reader to deliver mail.
     * add to register-linked-list when current robot arrives destination floor
     *
     * @param robot
     */
    void registerDelivery(IRobot robot);

    /**
     * When robot finished delivering, it should un register
     * remove from register-linked-list when current robot leave destination floor
     *
     * @param robot
     */
    void unregisterDelivery(IRobot robot);

    /**
     * When there is no robot is delivering fragile mail on the current floor
     * current robot could entry this floor.
     *
     * @param currentRobot
     * @return true or false
     */
    boolean checkDeliveryAllowed(IRobot currentRobot);

    /**
     * Check if current robot is have been already registered
     *
     * @param currentRobot
     * @return
     */
    boolean isRegistered(IRobot currentRobot);

    /**
     * load up any waiting robots with mailItems, if any.
     */
    void step() throws ItemTooHeavyException, BreakingFragileItemException;

    /**
     * refers to a robot which has arrived back ready for more mailItems to deliver
     *
     * @param robot
     */
    void registerWaiting(IRobot robot);

}
