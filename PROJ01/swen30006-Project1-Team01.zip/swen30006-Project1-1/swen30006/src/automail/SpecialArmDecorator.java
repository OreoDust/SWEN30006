package automail;

import automail.Robot.RobotState;
import exceptions.BreakingFragileItemException;
import exceptions.ExcessiveDeliveryException;
import exceptions.ItemTooHeavyException;

public class SpecialArmDecorator implements IRobot {

    static public final int INDIVIDUAL_MAX_WEIGHT = 2000;

    /**
     * Fragile mail need 2 units time to wrapping
     */
    private static final int WRAPPING_TIME = 2;

    /**
     * Fragile mail need i units time to unwrapping
     */
    private static final int UNWRAPPING_TIME = 1;

    private Robot robot;
    private MailItem fragileItem;

    private int wrapping_count;
    private int unwrapping_count;
    private int deliveryCounter;

    private boolean receivedDispatch;
    private boolean isWrapping;
    private boolean isUnwrapping;

    /**
     * Initiates the special robot's location at the start to be at the mail room
     * also set it to be waiting for mail.
     *
     * @param robot This robot will be decorated with special arms
     */
    public SpecialArmDecorator(Robot robot) {
        this.robot = robot;
        fragileItem = null;
        wrapping_count = 0;
        unwrapping_count = 0;
        this.receivedDispatch = false;
        this.isWrapping = false;
        this.isUnwrapping = false;
        this.deliveryCounter = 0;
    }

    /**
     * For case DELIVERING
     * When robot is ready to get into destination floor,
     * it should check if there is a fragile mail is delivering on that floor
     * if robot is allowed to get into destination floor, it should register.
     * <p>
     * When robot finish delivering and leave from current floor
     * it should unregister, that allow other robot could get into this floor.
     * <p>
     *
     * @see IRobot#step()
     */
    @Override
    public void step() throws ExcessiveDeliveryException {
        switch (robot.getCurrentState()) {
            /** This state is triggered when the robot is returning to the mailroom after a delivery */
            case RETURNING:
                /** If its current position is at the mailroom, then the robot should change state */
                if (robot.getCurrentFloor() == Building.MAILROOM_LOCATION) {
                    /** Tell the sorter the robot is ready */
                    robot.getMailpool().registerWaiting(this);
                    changeState(RobotState.WAITING);
                } else {
                    /** If the robot is not at the mailroom floor yet, then move towards it! */
                    moveTowards(Building.MAILROOM_LOCATION);
                    break;
                }
            case WAITING:
                /** If the StorageTube is ready and the Robot is waiting in the mailroom then start the delivery */
                if (!isEmpty() && receivedDispatch) {

                    receivedDispatch = false;
                    deliveryCounter = 0; // reset delivery counter
                    if (fragileItem != null) { // prioritise fragile items first
                        // Wrapping the package
                        if (wrapping_count < WRAPPING_TIME) {
                            this.isWrapping = true;
                            wrapping_count++;
                            receivedDispatch = true;
                            break;
                        } else {
                            this.isWrapping = false;
                            setRoute(fragileItem);
                            wrapping_count = 0;
                        }
                    } else {
                        setRoute(robot.getDeliveryItem());
                    }
                    changeState(RobotState.DELIVERING);
                }
                break;
            case DELIVERING:
                if (robot.getCurrentFloor() == robot.getDestinationFloor()) { // If already here drop off either way
                    if (robot.getMailpool().checkDeliveryAllowed(this)) {
                        if (unwrapping_count == 0) {
                            robot.getMailpool().registerDelivery(this);
                        }
                        if (fragileItem != null) {
                            // Unwrapping the package
                            if (unwrapping_count < UNWRAPPING_TIME) {
                                this.isUnwrapping = true;
                                unwrapping_count++;
                                break;
                            } else {
                                this.isUnwrapping = false;
                                robot.getDelivery().deliver(fragileItem);
                                fragileItem = null;
                                unwrapping_count = 0;
                            }
                        }
                        /** Delivery complete, report this to the simulator! */
                        if (deliveryCounter > 3) {  // Implies a simulation bug
                            throw new ExcessiveDeliveryException();
                        }
                        /** Check if want to return, i.e. if there is no item in the tube*/
                        if (robot.getDeliveryItem() == null && robot.getTube() == null) {
                            changeState(RobotState.RETURNING);
                        } else {
                            if (robot.getDeliveryItem() != null) {
                                robot.getDelivery().deliver(robot.getDeliveryItem());
                                robot.setDeliveryItem(null);
                                deliveryCounter++;
                                if (robot.getTube() != null) {
                                    /** If there is another item, set the robot's route to the location to deliver the item */
                                    robot.setDeliveryItem(robot.getTube());
                                    robot.setTube(null);
                                    setRoute(robot.getDeliveryItem());
                                    changeState(RobotState.DELIVERING);
                                } else {
                                    changeState(RobotState.RETURNING);
                                }
                            }
                        }
                    }
                    if (robot.getMailpool().isRegistered(this)) {
                        robot.getMailpool().unregisterDelivery(this);
                    }
                } else {
                    /** The robot is not at the destination yet, move towards it! */
                    moveTowards(robot.getDestinationFloor());
                }
                break;
        }
    }

    /**
     * Sets the route for the robot
     *
     * @param mailItem Mail that robot will deliver
     */
    protected void setRoute(MailItem mailItem) {
        /** Set the destination floor */
        robot.setDestinationFloor(mailItem.getDestFloor());
    }

    /**
     * @see IRobot#moveTowards(int)
     */
    @Override
    public void moveTowards(int destination) {
        robot.moveTowards(destination);
    }

    @Override
    public void changeState(RobotState nextState) {
        if (fragileItem != null) {
            System.out.printf("T: %3d > %9s-> [%s]%n", Clock.Time(), robot.getIdTube(), fragileItem.toString());
        }
        robot.changeState(nextState);
    }


    /**
     * @see IRobot#dispatch()
     */
    @Override
    public void dispatch() {
        receivedDispatch = true;
    }

    @Override
    public boolean isEmpty() {
        return (fragileItem == null && robot.getDeliveryItem() == null && robot.getTube() == null);
    }

    public boolean hasFragile() {
        return fragileItem != null;
    }

    @Override
    public boolean isWrapping() {
        return this.isWrapping;
    }

    @Override
    public boolean isUnwrapping() {
        return this.isUnwrapping;
    }

    /**
     * @see IRobot#addToHand(MailItem)
     */
    @Override
    public void addToHand(MailItem mailItem) throws ItemTooHeavyException, BreakingFragileItemException {
        assert (robot.getDeliveryItem() == null);
        if (mailItem.fragile) {
            fragileItem = mailItem;
        } else {
            robot.setDeliveryItem(mailItem);
        }

        if (mailItem.weight > INDIVIDUAL_MAX_WEIGHT) throw new ItemTooHeavyException();
    }

    /**
     * @see IRobot#addToTube(MailItem)
     */
    @Override
    public void addToTube(MailItem mailItem) throws ItemTooHeavyException, BreakingFragileItemException {
        robot.addToTube(mailItem);

    }

    @Override
    public int getCurrentFloor() {
        return robot.getCurrentFloor();
    }

    @Override
    public int getDestinationFloor() {
        return robot.getDestinationFloor();
    }
}