package automail;

import automail.Robot.RobotState;
import exceptions.BreakingFragileItemException;
import exceptions.ExcessiveDeliveryException;
import exceptions.ItemTooHeavyException;

public interface IRobot {

    /**
     * This is called on every time step
     *
     * @throws ExcessiveDeliveryException if robot delivers more than the capacity of the tube without refilling
     */
    void step() throws ExcessiveDeliveryException;

    /**
     * Generic function that moves the robot towards the destination
     *
     * @param destination the floor towards which the robot is moving
     */
    void moveTowards(int destination);

    /**
     * Robot start to dispatch
     */
    void dispatch();

    /**
     * Prints out the change in state
     *
     * @param nextState the state to which the robot is transitioning
     */
    void changeState(RobotState nextState);

    /**
     * Test whether current robot carry fragile mail.
     *
     * @return If current robot carry fragile mail return true, otherwise return false.
     */
    boolean hasFragile();

    /**
     * Check whether current robot dose not carry any mails
     *
     * @return
     */
    boolean isEmpty();

    /**
     * When robot with special arm is wrapping
     */
    boolean isWrapping();

    /**
     * When robot with special arm is unwrapping
     */
    boolean isUnwrapping();

    int getCurrentFloor();

    int getDestinationFloor();

    /**
     * Add mail to Robot's Hand
     *
     * @param mailItem
     * @throws ItemTooHeavyException
     * @throws BreakingFragileItemException
     */
    void addToHand(MailItem mailItem) throws ItemTooHeavyException, BreakingFragileItemException;

    /**
     * Add mail to Robot's Tube
     *
     * @param mailItem
     * @throws ItemTooHeavyException
     * @throws BreakingFragileItemException
     */
    void addToTube(MailItem mailItem) throws ItemTooHeavyException, BreakingFragileItemException;


}