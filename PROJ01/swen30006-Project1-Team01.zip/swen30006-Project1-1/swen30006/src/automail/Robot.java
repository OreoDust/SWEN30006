package automail;

import exceptions.BreakingFragileItemException;
import exceptions.ExcessiveDeliveryException;
import exceptions.ItemTooHeavyException;
import strategies.IMailPool;

import java.util.Map;
import java.util.TreeMap;

/**
 * The robot delivers mail!
 */
public class Robot implements IRobot {

    static public final int INDIVIDUAL_MAX_WEIGHT = 2000;

    /**
     * Possible states the robot can be in
     */
    public enum RobotState {
        DELIVERING, WAITING, RETURNING
    }

    public RobotState currentState;

    protected final String id;
    private int currentFloor;
    private int destinationFloor;
    private int deliveryCounter;
    private IMailPool mailPool;
    private MailItem deliveryItem = null;
    private MailItem tube = null;
    private IMailDelivery delivery;

    private boolean receivedDispatch;

    /**
     * Initiates the robot's location at the start to be at the mailroom
     * also set it to be waiting for mail.
     * behaviour governs selection of mail items for delivery and behaviour on priority arrivals
     *
     * @param delivery governs the final delivery
     * @param mailPool is the source of mail items
     */
    public Robot(IMailDelivery delivery, IMailPool mailPool) {
        id = "R" + hashCode();
        // currentState = RobotState.WAITING;
        currentState = RobotState.RETURNING;
        currentFloor = Building.MAILROOM_LOCATION;
        this.delivery = delivery;
        this.mailPool = mailPool;
        this.receivedDispatch = false;
        this.deliveryCounter = 0;
    }


    /**
     * @see IRobot#step()
     */
    public void step() throws ExcessiveDeliveryException {
        switch (currentState) {
            /** This state is triggered when the robot is returning to the mailroom after a delivery */
            case RETURNING:
                /** If its current position is at the mailroom, then the robot should change state */
                if (currentFloor == Building.MAILROOM_LOCATION) {
                    if (tube != null) {
                        mailPool.addToPool(tube);
                        System.out.printf("T: %3d >  +addToPool [%s]%n", Clock.Time(), tube.toString());
                        tube = null;
                    }
                    /** Tell the sorter the robot is ready */
                    mailPool.registerWaiting(this);
                    changeState(RobotState.WAITING);
                } else {
                    /** If the robot is not at the mailroom floor yet, then move towards it! */
                    moveTowards(Building.MAILROOM_LOCATION);
                    break;
                }
            case WAITING:
                /** If the StorageTube is ready and the Robot is waiting in the mailroom then start the delivery */
                if (!isEmpty() && receivedDispatch) {
                    receivedDispatch = false;
                    deliveryCounter = 0; // reset delivery counter
                    setRoute();
                    changeState(RobotState.DELIVERING);
                }
                break;
            case DELIVERING:
                if (currentFloor == destinationFloor) { // If already here drop off either way
                    /** Delivery complete, report this to the simulator! */
                    delivery.deliver(deliveryItem);
                    deliveryItem = null;
                    deliveryCounter++;
                    if (deliveryCounter > 2) {  // Implies a simulation bug
                        throw new ExcessiveDeliveryException();
                    }
                    /** Check if want to return, i.e. if there is no item in the tube*/
                    if (tube == null) {
                        changeState(RobotState.RETURNING);
                    } else {
                        /** If there is another item, set the robot's route to the location to deliver the item */
                        deliveryItem = tube;
                        tube = null;
                        setRoute();
                        changeState(RobotState.DELIVERING);
                    }
                } else {
                    /** The robot is not at the destination yet, move towards it! */
                    moveTowards(destinationFloor);
                }
                break;
        }
    }

    /**
     * Sets the route for the robot
     */
    public void setRoute() {
        /** Set the destination floor */
        destinationFloor = deliveryItem.getDestFloor();
    }

    /**
     * @see IRobot#moveTowards(int)
     */
    public void moveTowards(int destination) {
        if (currentFloor < destination) {
            currentFloor++;
        } else {
            currentFloor--;
        }
    }

    /**
     * @see IRobot#changeState(RobotState)
     */
    public void changeState(RobotState nextState) {
        assert (!(deliveryItem == null && tube != null));
        if (currentState != nextState) {
            System.out.printf("T: %3d > %7s changed from %s to %s%n", Clock.Time(), getIdTube(), currentState, nextState);
        }
        currentState = nextState;
        if (deliveryItem != null) {
            System.out.printf("T: %3d > %9s-> [%s]%n", Clock.Time(), getIdTube(), deliveryItem.toString());
        }
    }

    /**
     * @see IRobot#dispatch()
     */
    public void dispatch() {
        receivedDispatch = true;
    }

    @Override
    public boolean isWrapping() {
        return true;
    }

    @Override
    public boolean isUnwrapping() {
        return true;
    }

    static private int count = 0;
    static private Map<Integer, Integer> hashMap = new TreeMap<Integer, Integer>();

    @Override
    public int hashCode() {
        Integer hash0 = super.hashCode();
        Integer hash = hashMap.get(hash0);
        if (hash == null) {
            hash = count++;
            hashMap.put(hash0, hash);
        }
        return hash;
    }

    @Override
    public boolean hasFragile() {
        return false;
    }

    public boolean isEmpty() {
        return (deliveryItem == null && tube == null);
    }

    /**
     * @see IRobot#addToHand(MailItem)
     */
    public void addToHand(MailItem mailItem) throws ItemTooHeavyException, BreakingFragileItemException {
        assert (deliveryItem == null);
        if (mailItem.fragile) throw new BreakingFragileItemException();
        deliveryItem = mailItem;
        if (deliveryItem.weight > INDIVIDUAL_MAX_WEIGHT) throw new ItemTooHeavyException();
    }

    /**
     * @see IRobot#addToTube(MailItem)
     */
    public void addToTube(MailItem mailItem) throws ItemTooHeavyException, BreakingFragileItemException {
        assert (tube == null);
        if (mailItem.fragile) throw new BreakingFragileItemException();
        tube = mailItem;
        if (tube.weight > INDIVIDUAL_MAX_WEIGHT) throw new ItemTooHeavyException();
    }


    public String getIdTube() {
        return String.format("%s(%1d)", id, (tube == null ? 0 : 1));
    }


    public RobotState getCurrentState() {
        return this.currentState;
    }

    public int getCurrentFloor() {
        return this.currentFloor;
    }

    public int getDestinationFloor() {
        return this.destinationFloor;
    }

    public void setDestinationFloor(int floor) {
        destinationFloor = floor;
    }

    public IMailPool getMailpool() {
        return this.mailPool;
    }

    public IMailDelivery getDelivery() {
        return this.delivery;
    }

    public void setDeliveryItem(MailItem item) {
        deliveryItem = item;
    }

    public MailItem getDeliveryItem() {
        return deliveryItem;
    }

    public MailItem getTube() {
        return tube;
    }

    public void setTube(MailItem item) {
        tube = item;
    }


}
