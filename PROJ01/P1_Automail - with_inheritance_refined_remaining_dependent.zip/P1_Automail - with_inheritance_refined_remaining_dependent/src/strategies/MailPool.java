package strategies;

import java.util.LinkedList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.ListIterator;

import automail.MailItem;
import automail.Robot;
import automail.CautionRobot;
import exceptions.BreakingFragileItemException;
import exceptions.ItemTooHeavyException;

public class MailPool implements IMailPool {

	private static boolean CAUTION_MODE;

	private class Item {
		int destination;
		MailItem mailItem;

		public Item(MailItem mailItem) {
			destination = mailItem.getDestFloor();
			this.mailItem = mailItem;
		}
	}

	public class ItemComparator implements Comparator<Item> {
		@Override
		public int compare(Item i1, Item i2) {
			int order = 0;
			if (i1.destination > i2.destination) { // Further before closer
				order = 1;
			} else if (i1.destination < i2.destination) {
				order = -1;
			}
			return order;
		}
	}

	private LinkedList<Item> pool;
	private LinkedList<Robot> robots;
	private LinkedList<CautionRobot> cautionRobots;
	private HashMap<Integer, LinkedList<CautionRobot>> deliveringRobots;

	public MailPool(int nrobots, boolean CAUTION_ENABLED) {
		// Start empty
		CAUTION_MODE = CAUTION_ENABLED;
		pool = new LinkedList<Item>();
		deliveringRobots = new HashMap<Integer, LinkedList<CautionRobot>>();
		if (CAUTION_MODE) {
			cautionRobots = new LinkedList<CautionRobot>();
		} else {
			robots = new LinkedList<Robot>();
		}
	}

	public void addToPool(MailItem mailItem) {
		Item item = new Item(mailItem);
		pool.add(item);
		pool.sort(new ItemComparator());
	}

	public void registerDelivery(CautionRobot robot) {
		int dest_floor = robot.getDestinationFloor();
		if (deliveringRobots.get(dest_floor) == null) {
			LinkedList<CautionRobot> onFloorRobots = new LinkedList<>();
			onFloorRobots.add(robot);
			deliveringRobots.put(dest_floor, onFloorRobots);
		} else {
			deliveringRobots.get(dest_floor).add(robot);
		}
	}

	public void unregisterDelivery(CautionRobot robot) {
		deliveringRobots.get(robot.getCurrentFloor()).remove(robot);
	}

	public boolean checkFloorEmpty(CautionRobot currentRobot) {
		LinkedList<CautionRobot> onFloorRobots = deliveringRobots.get(currentRobot.getCurrentFloor()); 
		return onFloorRobots == null;
	}

	public boolean checkDeliveryAllowed(CautionRobot currentRobot) {
		LinkedList<CautionRobot> onFloorRobots = deliveringRobots.get(currentRobot.getCurrentFloor());
		if (onFloorRobots != null) {
			System.out.println(deliveringRobots);
			if (onFloorRobots.stream().filter(robot -> robot.hasFragile()).findAny().isPresent()) {
				return onFloorRobots.getFirst().equals(currentRobot);
			} else {
				return true;
			}
		} else {
			return true;
		}
	}

	public boolean isRegistered(CautionRobot currentRobot) {
		return deliveringRobots.get(currentRobot.getCurrentFloor()) != null;
	}

	@Override
	public void step(double optimal_load) throws ItemTooHeavyException, BreakingFragileItemException {
		try {
			if (CAUTION_MODE) {
				ListIterator<CautionRobot> i = cautionRobots.listIterator();
				while (i.hasNext())
					loadCautionRobot(i, optimal_load);
			} else {
				ListIterator<Robot> i = robots.listIterator();
				while (i.hasNext())
					loadRobot(i);
			}
		} catch (Exception e) {
			try {
				throw e;
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	private void loadRobot(ListIterator<Robot> i) throws ItemTooHeavyException, BreakingFragileItemException {
		Robot robot = i.next();
		assert (robot.isEmpty());
		// System.out.printf("P: %3d%n", pool.size());
		ListIterator<Item> j = pool.listIterator();
		if (pool.size() > 0) {
			try {
				robot.addToHand(j.next().mailItem); // hand first as we want higher priority delivered first
				j.remove();
				if (pool.size() > 0) {
					robot.addToTube(j.next().mailItem);
					j.remove();
				}
				robot.dispatch(); // send the robot off if it has any items to deliver
				i.remove(); // remove from mailPool queue
			} catch (Exception e) {
				throw e;
			}
		}
	}

	private void loadCautionRobot(ListIterator<CautionRobot> i, double optimal_load) throws ItemTooHeavyException {
		CautionRobot robot = i.next();
		assert (robot.isEmpty());
		// System.out.printf("P: %3d%n", pool.size());
		ListIterator<Item> j = pool.listIterator();
		if (pool.size() > 0) {
			boolean inHand = false;
			boolean inTube = false;
			int current_load = 0;
			try {
				while(pool.size() > 0 && current_load <= optimal_load) {
					MailItem item = j.next().mailItem;
					if (item.isFragile()) {
						if (!robot.hasFragile()) {
							robot.addToSpecHand(item);
							j.remove();
							current_load++;
						} else {
							break;
						}
					} else {
						if (!inHand) {
							robot.addToHand(item);
							j.remove();
							current_load++;
							inHand = true;
						} else if (!inTube) {
							robot.addToTube(item);
							j.remove();
							current_load++;
							inTube = true;
						} else {
							break;
						}
					}		
				}
				robot.dispatch(); // send the robot off if it has any items to deliver
				i.remove(); // remove from mailPool queue
			} catch (Exception e) {
				try {
					throw e;
				} catch (Exception e1) {
					e1.printStackTrace();
				}
	        } 
		}
	}

	public void registerWaiting(Robot robot) { // assumes won't be there already
		robots.add(robot);
	}

	public void registerWaiting(CautionRobot robot) { // assumes won't be there already
		cautionRobots.add(robot);
	}

}
