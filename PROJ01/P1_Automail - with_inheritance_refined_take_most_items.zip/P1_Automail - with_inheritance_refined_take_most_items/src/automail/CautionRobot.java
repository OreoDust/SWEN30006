package automail;

import exceptions.ItemTooHeavyException;
import exceptions.ExcessiveDeliveryException;
import strategies.IMailPool;

public class CautionRobot extends Robot {
	
	private int WRAPPING_TIME = 2;
	private int UNWRAPPING_TIME = 1;
	private int wrapping_count;
	private int unwrapping_count;
    private MailItem fragileItem = null;

	public CautionRobot(IMailDelivery delivery, IMailPool mailPool) {
		super(delivery, mailPool);
		this.wrapping_count = 0;
		this.unwrapping_count = 0;
	}
	
    public void step() throws ExcessiveDeliveryException {    	
    	switch(current_state) {
    		/** This state is triggered when the robot is returning to the mailroom after a delivery */
    		case RETURNING:
    			/** If its current position is at the mailroom, then the robot should change state */
                if(current_floor == Building.MAILROOM_LOCATION){
                	if (tube != null) {
                		mailPool.addToPool(tube);
                        System.out.printf("T: %3d >  +addToPool [%s]%n", Clock.Time(), tube.toString());
                        tube = null;
                	}
        			/** Tell the sorter the robot is ready */
					mailPool.registerWaiting(this);
                	changeState(RobotState.WAITING);
                } else {
                	/** If the robot is not at the mailroom floor yet, then move towards it! */
                    moveTowards(Building.MAILROOM_LOCATION);
                	break;
                }
			case WAITING:
                /** If the StorageTube is ready and the Robot is waiting in the mailroom then start the delivery */
				if(!isEmpty() && receivedDispatch) {
                	receivedDispatch = false;
                	deliveryCounter = 0; // reset delivery counter
					if (fragileItem != null) { // prioritise fragile items first
						// Wrapping the package
						if (wrapping_count < WRAPPING_TIME) {
							System.out.printf("T: %3d = WRAPPING\n", Clock.Time());
							wrapping_count++;
							receivedDispatch = true;
							break;
						} else {
							setRoute(fragileItem);
							wrapping_count = 0;
						}
        			} else {
						setRoute(deliveryItem);
					}
					changeState(RobotState.DELIVERING);
					receivedDispatch = false;
				} 
				break;
			case DELIVERING:
				if(current_floor == destination_floor) { // If already here drop off either way
					if(mailPool.checkFloorEmpty(this)) {
						mailPool.registerDelivery(this);
					}
					if (mailPool.checkDeliveryAllowed(this)) {
						if (fragileItem != null) {
							// Unwrapping the package
							if (unwrapping_count < UNWRAPPING_TIME) {
								System.out.printf("T: %3d = UNWRAPPING\n", Clock.Time());
								unwrapping_count++;
								break;
							} else {
								delivery.deliver(fragileItem);
								fragileItem = null;
								unwrapping_count = 0;
							}
	                    }
	    				/** Delivery complete, report this to the simulator! */
	                    if(deliveryCounter > 3){  // Implies a simulation bug
	                    	throw new ExcessiveDeliveryException();
	                    }
	                    /** Check if want to return, i.e. if there is no item in the tube*/
	                    if(deliveryItem == null && tube == null){
	                    	changeState(RobotState.RETURNING);
	                    } else {
	                    	if (deliveryItem != null) {
	                    		delivery.deliver(deliveryItem);
	                            deliveryItem = null;
	                            deliveryCounter++;
	                            if (tube != null) {
	                            	/** If there is another item, set the robot's route to the location to deliver the item */
	                                deliveryItem = tube;
	                                tube = null;
	                                setRoute(deliveryItem);
	                                changeState(RobotState.DELIVERING);
	                            } else {
									changeState(RobotState.RETURNING);
								}
	                    	}
						}
					}
					if (mailPool.isRegistered(this)) {
						mailPool.unregisterDelivery(this);
					}
    			} else {
	        		/** The robot is not at the destination yet, move towards it! */
	                moveTowards(destination_floor);
    			}
    	}
	}

	@Override
	public void moveTowards(int destination) {
		// Unregister delivery
		if (mailPool.isRegistered(this)) {
			mailPool.unregisterDelivery(this);
		}
        if(current_floor < destination){
            current_floor++;
        } else {
            current_floor--;
		}
		// Register delivery
		if (current_floor == destination_floor) {
			if (mailPool.checkDeliveryAllowed(this)) {
				mailPool.registerDelivery(this);
			}
		}
    } 
	
	/**
     * Prints out the change in state
     * @param nextState the state to which the robot is transitioning
     */
    public void changeState(RobotState nextState){
    	assert(!(fragileItem == null && deliveryItem == null && tube != null));
    	if (current_state != nextState) {
            System.out.printf("T: %3d > %7s changed from %s to %s%n", Clock.Time(), getIdTube(), current_state, nextState);
		}
    	current_state = nextState;
    	if(nextState == RobotState.DELIVERING){
			if (deliveryItem != null) {
    			System.out.printf("T: %3d > %9s-> [%s]%n", Clock.Time(), getIdTube(), deliveryItem.toString());
    		} else if (fragileItem != null) {
    			System.out.printf("T: %3d > %9s-> [%s]%n", Clock.Time(), getIdTube(), fragileItem.toString());
    		}
		}
	}

	public int getCurrentFloor() {
		return this.current_floor;
	}
	
	public int getDestinationFloor() {
		return this.destination_floor;
	}

	public boolean hasFragile() {
		return fragileItem != null;	
	}

	public boolean isEmpty() {
		return (fragileItem == null && deliveryItem == null && tube == null);
	}

	public void addToSpecHand(final MailItem mailItem) throws ItemTooHeavyException {
		assert(fragileItem == null);
		fragileItem = mailItem;
		System.out.printf("MailId: %s Added to %s special hand\n", fragileItem.id, id);
		if (fragileItem.weight > INDIVIDUAL_MAX_WEIGHT) throw new ItemTooHeavyException();	
	}
}
