package strategies;

import automail.CautionRobot;
import automail.IMailDelivery;
import automail.Robot;

public class Automail {
	      
	public Robot[] robots;
	public CautionRobot[] cautionRobots;
    public IMailPool mailPool;
    
    public Automail(IMailPool mailPool, IMailDelivery delivery, int numRobots, boolean CAUTION_ENABLED) {
    	// Swap between simple provided strategies and your strategies here
    	    	
    	/** Initialize the MailPool */
    	
    	this.mailPool = mailPool;
    	
		/** Initialize robots */
		if (CAUTION_ENABLED) {
			cautionRobots = new CautionRobot[numRobots];
			for (int i = 0; i < numRobots; i++) cautionRobots[i] = new CautionRobot(delivery, mailPool);
		} else {
			robots = new Robot[numRobots];
			for (int i = 0; i < numRobots; i++) robots[i] = new Robot(delivery, mailPool);
		}
    }
}
